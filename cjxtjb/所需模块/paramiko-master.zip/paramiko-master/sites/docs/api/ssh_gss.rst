GSS-API authentication
======================

.. automodule:: paramiko.ssh_gss
    :member-order: bysource

.. autoclass:: _SSH_GSSAuth
    :member-order: bysource

.. autoclass:: _SSH_GSSAPI
    :member-order: bysource

.. autoclass:: _SSH_SSPI
    :member-order: bysource
